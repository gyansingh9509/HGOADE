
                      
%              Chaotic GSA for Mechanical Engineering Design Problems
% 
%                  E-Mail: sajad.win8@gmail.com                   
%                                                                         
%              Homepage: https://github.com/SajadAHMAD1.                            
%                                                                         
%   Main paper: Rather, S. and Bala, P. (2020), "Swarm-based chaotic gravitational search algorithm for solving mechanical engineering design problems",
%                                               World Journal of Engineering, Vol. 17 No. 1, pp. 97-114. https://doi.org/10.1108/WJE-09-2019-0254    

%               Department of Computer Science and Engineering
%               School of Engineering and Technology
%               Pondicherry University- 605014, India
%               
%   Programmer: Sajad Ahmad Rather      
%   Developed in MATLAB R2013a 


% This function calculates the value of objective function.
function PHI=benchmark_functions(x,Benchmark_Function_ID,dim)

% // Penalty Function Method has been used to deal with Constraints \\

if Benchmark_Function_ID==1 % Welded Beam Design (WBD)

P = 6000; % APPLIED TIP LOAD
E = 30e6; % YOUNGS MODULUS OF BEAM
G = 12e6; % SHEAR MODULUS OF BEAM
tem = 14; % LENGTH OF CANTILEVER PART OF BEAM
PCONST = 100000; % PENALTY FUNCTION CONSTANT
TAUMAX = 13600; % MAXIMUM ALLOWED SHEAR STRESS
SIGMAX = 30000; % MAXIMUM ALLOWED BENDING STRESS
DELTMAX = 0.25; % MAXIMUM ALLOWED TIP DEFLECTION
M =  P*(tem+x(2)/2); % BENDING MOMENT AT WELD POINT
R = sqrt((x(2)^2)/4+((x(1)+x(3))/2)^2); % SOME CONSTANT
J =  2*(sqrt(2)*x(1)*x(2)*((x(2)^2)/4+((x(1)+x(3))/2)^2)); % POLAR MOMENT OF INERTIA
PHI =  1.10471*x(1)^2*x(2)+0.04811*x(3)*x(4)*(14+x(2)); % OBJECTIVE FUNCTION
SIGMA = (6*P*tem)/(x(4)*x(3)^2); % BENDING STRESS
DELTA = (4*P*tem^3)/(E*x(3)^3*x(4)); % TIP DEFLECTION
PC = 4.013*E*sqrt((x(3)^2*x(4)^6)/36)*(1-x(3)*sqrt(E/(4*G))/(2*tem))/(tem^2); % BUCKLING LOAD
TAUP =  P/(sqrt(2)*x(1)*x(2)); % 1ST DERIVATIVE OF SHEAR STRESS
TAUPP = (M*R)/J; % 2ND DERIVATIVE OF SHEAR STRESS
TAU = sqrt(TAUP^2+2*TAUP*TAUPP*x(2)/(2*R)+TAUPP^2); % SHEAR STRESS
G1 = TAU-TAUMAX; % MAX SHEAR STRESS CONSTRAINT
G2 =  SIGMA-SIGMAX; % MAX BENDING STRESS CONSTRAINT
%G3 = L(1)-L(4); % WELD COVERAGE CONSTRAINT
G3=DELTA-DELTMAX;
G4=x(1)-x(4);
G5=P-PC;
G6=0.125-x(1); 
%G4 = 0.10471*L(1)^2+0.04811*L(3)*L(4)*(14+L(2))-5; % MAX COST CONSTRAINT
%G5 =  0.125-L(1); % MAX WELD THICKNESS CONSTRAINT
%G6 =  DELTA-DELTMAX; % MAX TIP DEFLECTION CONSTRAINT
%G7 =  P-PC; % BUCKLING LOAD CONSTRAINT
G7=1.10471*x(1)^2+0.04811*x(3)*x(4)*(14+x(2))-5;
PHI = PHI + PCONST*(max(0,G1)^2+max(0,G2)^2+...
    max(0,G3)^2+max(0,G4)^2+max(0,G5)^2+...
    max(0,G6)^2+max(0,G7)^2); % PENALTY FUNCTION
end

if Benchmark_Function_ID==2 % Compression Spring Design (CSD)
    


PCONST = 100; % PENALTY FUNCTION CONSTANT

fit=(x(3)+2)*x(2)*(x(1)^2);
G1=1-((x(2)^3)*x(3))/(71785*x(1)^4);
G2=((4*x(2)^2)-x(1)*x(2))/(12566*(x(2)*(x(1)^3)-x(1)^4))+1/(5108*x(1)^2);
G3=1-(140.45*x(1))/((x(2)^2)*x(3));
G4=((x(1)+x(2))/1.5)-1;

PHI = fit + PCONST*(max(0,G1)^2++max(0,G2)^2+...
    max(0,G3)^2+max(0,G4)^2); % PENALTY FUNCTION
end

if Benchmark_Function_ID==3 % Pressure Vessel Design (PVD)

PCONST=10000;  % PENALTY FUNCTION CONSTANT
fit= 0.6224*x(1)*x(3)*x(4)+ 1.7781*x(2)*(x(3)^2) + 3.1661 *(x(1)^2)*x(4) + 19.84 * (x(1)^2)*x(3);
G1= -x(1)+ 0.0193*x(3);
G2=  -x(2) + 0.00954* x(3);
G3=  -pi*(x(3)^2)*x(4)-(4/3)* pi*x(3)^3 +1296000;
G4= x(4) - 240;
PHI =fit + PCONST*(max(0,G1)^2+max(0,G2)^2+...
    max(0,G3)^2+max(0,G4)^2); % PENALTY FUNCTION
end
if Benchmark_Function_ID==4 % Speed Reducer Design (SRD)
    PCONST = 1000000;                                                               % Penalty Function Constant

    PHI= 0.7854*x(1)*x(2)^2 * (3.3333*x(3)^2  + 14.9334*x(3) -  43.0934)...
		-1.508*x(1)*(x(6)^2 + x(7)^2) + 7.4777*(x(6)^3 + x(7)^3)...
		+0.7854*(x(4)*x(6)^2 + x(5)*x(7)^2);                                    % Objective Function f(x)

        g1  =  	(27 / (x(1)*x(2)^2*x(3)))-1; 
        g2  =  	(397.5 / (x(1) * x(2)^2 * x(3)^2) )- 1; 
        g3 	=  	((1.93 * x(4)^2) / (x(2) * x(3) * x(6)^4) ) -1 ; 
        g4 	=  	((1.93 * x(5)^2) /(x(2) * x(3) * x(7)^4)) - 1; 

        g5 	= 	((1/(110*x(6)^3)) *(sqrt((745*x(4)  / (x(2)*x(3))  )^2 + 16.9e6)) ) - 1; 
        g6 	= 	((1/(85*x(7)^3)) *(sqrt((745*x(5)  / (x(2)*x(3))  )^2 + 157.5e6)) ) - 1; 

        g7 	=  	(x(2)*x(3) / 40 )- 1;  
        g8 	= 	(5*x(2) / x(1)) -1; 
        g9 	= 	(x(1) / (12 * x(2))) - 1;
        g10 = 	((1.5*x(6) + 1.9) / (x(4))) -1 ; 
        g11 =  	((1.1*x(7) + 1.9) / (x(5))) -1; 



        PHI = PHI + PCONST*...
           (max(0,g1)^2+max(0,g2)^2+...
            max(0,g3)^2+max(0,g4)^2+max(0,g5)^2+...
            max(0,g6)^2+max(0,g7)^2+max(0,g8)^2+...
            max(0,g9)^2+max(0,g10)^2+max(0,g11)^2); % Penalty Function
end
if Benchmark_Function_ID==5     % Three-bar truss design problem
   PHI = (2.*sqrt(2).*x(:,1)+x(:,2))*100;
    g(:,1) = (sqrt(2).*x(:,1)+x(:,2))./(sqrt(2).*x(:,1).^2+2.*x(:,1).*x(:,2))*2-2;
    g(:,2) = x(:,2)./(sqrt(2).*x(:,1).^2+2.*x(:,1).*x(:,2))*2-2;
    g(:,3) = 1./(sqrt(2).*x(:,2)+x(:,1))*2-2;
    PHI=PHI+(max(0,g(:,1))^2+max(0,g(:,2))^2+max(0,g(:,3))^2);
end
if Benchmark_Function_ID==6     % Design of gear train
    x=round(x); term1=1/6.931; term2=(x(3)*x(2))/(x(1)*x(4));
    PHI = (term1-term2)^2;
    g = 0;
end
if Benchmark_Function_ID==7     % Cantilever beam
    PHI = 0.0624*(x(1)+x(2)+x(3)+x(4)+x(5));
    g1 = (61/x(1)^3)+(37/x(2)^3)+(19/x(3)^3)+(7/x(4)^3)+(1/x(5)^3)-1;
    PHI = PHI+(max(0,g1)^2);
end
if Benchmark_Function_ID==8     % Minimize I-beam vertical deflection
    term1 = x(3)*(x(1)-2*x(4))^3/12; term2 = x(2)*x(4)^3/6; term3 = 2*x(2)*x(4)*((x(1)-x(4))/2)^2;
    PHI = 5000/(term1+term2+term3);
    g1 = 2*x(2)*x(4)+x(3)*(x(1)-2*x(4))-300;
    term1 = x(3)*(x(1)-2*x(4))^3;
    term2 = 2*x(2)*x(4)*(4*x(4)^2+3*x(1)*(x(1)-2*x(4)));
    term3 = (x(1)-2*x(4))*x(3)^3;
    term4 = 2*x(4)*x(2)^3;
    g2 = ((18*x(1)*10^4)/(term1+term2))+((15*x(2)*10^3)/(term3+term4))-6;
    PHI=PHI+(max(0,g1)^2+max(0,g2)^2);
end
if Benchmark_Function_ID==9      % Tubular column design
    PHI = 9.8*x(1)*x(2)+2*x(1);
    g1=(2500/0.0025*x(1)*x(2)*500)-1;
    g2=((8*2500*250^2)/250^3*0.85*106*x(1)*x(2)*(x(1)^2+x(2)^2))-1;
    g3=2/x(1)-1;
    g4=x(1)/14-1;
    g5=0.2/x(2)-1;
    g6=x(2)/8-1;
    PHI=PHI+(max(0,g1)^2+max(0,g2)^2+max(0,g3)^2+max(0,g4)^2+max(0,g5)^2+max(0,g6)^2);
end
if Benchmark_Function_ID==10     % Piston lever
    teta = 45; H=x(1); B=x(2); D=x(3); X=x(4);
    l2=((X*sin(teta)+H)^2+(B-X*cos(teta))^2)^0.5;
    l1=((X-B)^2+H^2)^0.5;
    PHI=0.25*pi*D^2*(l2-l1);
    teta = 45; H=x(1); B=x(2); D=x(3); X=x(4); P=1500; Q=10000; L=240; Mmax=1.8e+6;
    R=abs(-X*(X*sin(teta)+H)+H*(B-X*cos(teta)))/sqrt((X-B)^2+H^2);
    F=0.25*pi*P*D^2;
    l2=((X*sin(teta)+H)^2+(B-X*cos(teta))^2)^0.5;
    l1=((X-B)^2+H^2)^0.5;
    g1=Q*L*cos(teta)-R*F;
    g2=Q*(L-X)-Mmax;
    g3=1.2*(l2-l1)-l1;
    g4=0.5*D-B;
    PHI=PHI+(max(0,g1)^2+max(0,g2)^2+max(0,g3)^2+max(0,g4)^2);
end
if Benchmark_Function_ID==11      % Corrugated bulkhead design
    b=x(1); h=x(2); l=x(3); t=x(4); ABD = abs(l^2-h^2);
    PHI = (5.885*t*(b+l))/(b+(abs(l^2-h^2))^0.5);
    g1=-t*h*(0.4*b+l/6)+8.94*(b+(ABD)^0.5);
    g2=-t*h^2*(0.2*b+l/12)+2.2*(8.94*(b+(ABD)^0.5))^(4/3);
    g3=-t+0.0156*b+0.15;
    g4=-t+0.0156*l+0.15;
    g5=-t+1.05;
    g6=-l+h;
    PHI=PHI+(max(0,g1)^2+max(0,g2)^2+max(0,g3)^2+max(0,g4)^2+max(0,g5)^2+max(0,g6)^2);
end
if Benchmark_Function_ID==12      % Car side impact design
    % Sections
    Sec8 = [0.192 0.345];
    Sec9 = [0.192 0.345];
    nSec8 = numel(Sec8);
    nSec9 = numel(Sec9);
    x(8) = Sec8(min(floor(x(8)*nSec8+1),nSec8));
    x(9) = Sec8(min(floor(x(9)*nSec9+1),nSec9));

    % Objective
    PHI=1.98+4.90*x(1)+6.67*x(2)+6.98*x(3)+4.01*x(4)+1.78*x(5)+2.73*x(7);

    % Subjective
    Fa =1.16-0.3717*x(2)*x(4)-0.00931*x(2)*x(10)-0.484*x(3)*x(9)+0.01343*x(6)*x(10);
    VCu =0.261-0.0159*x(1)*x(2)-0.188*x(1)*x(8)-0.019*x(2)*x(7)+0.0144*x(3)*x(5)+0.0008757*x(5)*x(10)+0.08045*x(6)*x(9)+0.00139*x(8)*x(11)+0.00001575*x(10)*x(11);
    VCm =0.214+0.00817*x(5)-0.131*x(1)*x(8)-0.0704*x(1)*x(9)+0.03099*x(2)*x(6)-0.018*x(2)*x(7)+0.0208*x(3)*x(8)+0.121*x(3)*x(9)-0.00364*x(5)*x(6)+0.0007715*x(5)*x(10)-0.0005354*x(6)*x(10)+0.00121*x(8)*x(11)+0.00184*x(9)*x(10)-0.02*x(2)^2;
    VCl=0.74-0.61*x(2)-0.163*x(3)*x(8)+0.001232*x(3)*x(10)-0.166*x(7)*x(9)+0.227*x(2)^(2);
    Dur=28.98+3.818*x(3)-4.2*x(1)*x(2)+0.0207*x(5)*x(10)+6.63*x(6)*x(9)-7.7*x(7)*x(8)+0.32*x(9)*x(10);
    Dmr=33.86+2.95*x(3)+0.1792*x(10)-5.057*x(1)*x(2)-11*x(2)*x(8)-0.0215*x(5)*x(10)-9.98*x(7)*x(8)+22*x(8)*x(9);
    Dlr=46.36-9.9*x(2)-12.9*x(1)*x(8)+0.1107*x(3)*x(10);
    Fp=4.72-0.5*x(4)-0.19*x(2)*x(3)-0.0122*x(4)*x(10)+0.009325*x(6)*x(10)+0.000191*x(11)^(2);
    VMBP=10.58-0.674*x(1)*x(2)-1.95*x(2)*x(8)+0.02054*x(3)*x(10)-0.0198*x(4)*x(10)+0.028*x(6)*x(10);
    VFD=16.45-0.489*x(3)*x(7)-0.843*x(5)*x(6)+0.0432*x(9)*x(10)-0.0556*x(9)*x(11)-0.000786*x(11)^(2);
    g = [Fa-1, VCu-0.32, VCm-0.32, VCl-0.32, Dur-32, Dmr-32, Dlr-32, Fp-4, VMBP-9.9, VFD-15.7];
    PHI=PHI+(max(0,g).^2);
end
if Benchmark_Function_ID==13       % Reinforced concrete beam design
    % Beam Design Params
    x1 = [6 6.16 6.32 6.6 7 7.11 7.2 7.8 7.9 8 8.4];
    nx1 = numel(x1);
    x2 = 28:40;
    nx2 = numel(x2);

    As = x1(min(floor(x(1)*nx1+1),nx1));
% As=x(1);
% b=x(2);
% h=x(3);
    b = x2(min(floor(x(2)*nx2+1),nx2));
    h = x(3);

    % Objective
    PHI=29*As+0.49*b*h;

    % Subjectives
    g1=b/h-4;
    g2=180+7.375*(As^2/h)-As*b;
    PHI=PHI+(max(0,g1)^2+max(0,g2)^2);
end
end

