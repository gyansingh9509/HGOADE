%  Sine Cosine Algorithm (SCA) 

% this function will create all initial solution set generated between lb
% and ub bound
%sca_no is the searchAgent number


function X=initialization(sca_no,dim,ub,lb)

Boundary_no= size(ub,2); % numnber of boundaries 

% If the boundaries of all variables are equal and user enter a signle
% number for both ub and lb
if Boundary_no==1
    X=rand(sca_no,dim).*(ub-lb)+lb;
end

% If each variable has a different lb and ub
if Boundary_no>1
    for i=1:dim
        ub_i=ub(i);
        lb_i=lb(i);
        X(:,i)=rand(sca_no,1).*(ub_i-lb_i)+lb_i;
    end
end
