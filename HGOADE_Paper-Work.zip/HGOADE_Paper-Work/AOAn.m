
function [Best_FF,Best_PP,Conv_curve]=AOAn(N,M_Iter,func_name)
display('AOA Working');
%Two variables to keep the positions and the fitness value of the best-obtained solution
[low,up,dim,fobj]=G_F_d(func_name);%define the boundary and dimension of the benchmark function
            LB=low;
            UB=up;
            Dim=dim;
Best_PP=zeros(1,Dim);
Best_FF=inf;
Conv_curve=zeros(1,M_Iter);

%Initialize the positions of solution
X=initializationAOAn(N,Dim,UB,LB);
Xnew=X;
Ffun=zeros(1,size(X,1));% (fitness values)
Ffun_new=zeros(1,size(Xnew,1));% (fitness values)

MOP_Max=1;
MOP_Min=0.2;
C_Iter=1;
Alpha=5;
Mu=0.499;

dim=Dim;
for i=1:size(X,1)
    Ffun(1,i)=fobj(X(i,:));  %Calculate the fitness values of solutions
    if Ffun(1,i)<Best_FF
        Best_FF=Ffun(1,i);
        Best_PP=X(i,:);
    end
end
    
    

while C_Iter<M_Iter+1  %Main loop
    MOP=1-((C_Iter)^(1/Alpha)/(M_Iter)^(1/Alpha));   % Probability Ratio 
    MOA=MOP_Min+C_Iter*((MOP_Max-MOP_Min)/M_Iter); %Accelerated function
   
    %Update the Position of solutions
    for i=1:size(X,1)   % if each of the UB and LB has a just value 
        for j=1:size(X,2)
           r1=rand();
            if (size(LB,1)==1)
                if r1<MOA
                    r2=rand();
                    if r2>0.5
                        Xnew(i,j)=Best_PP(1,j)/log(abs((MOP+eps).*((UB-LB)*Mu+LB)));
                    else
                        Xnew(i,j)=Best_PP(1,j)*exp((MOP+eps).*((UB-LB)*Mu+LB));
                    end
                else
                    r3=rand();
                    if r3>0.5
                        Xnew(i,j)=Best_PP(1,j)-MOP*((UB-LB).*Mu+LB);
                    else
                        Xnew(i,j)=Best_PP(1,j)+MOP*((UB-LB).*Mu+LB);
                    end
                 end               
             end
            
           if (size(LB,1)~=1)   % if each of the UB and LB has more than one value 
                r1=rand();
                if r1<MOA
                    r2=rand();
                    if r2>0.5
                        Xnew(i,j)=Best_PP(1,j)/log(abs(MOP+eps)*((UB(j)-LB(j))*Mu+LB(j)));
                    else
                        Xnew(i,j)=Best_PP(1,j)*exp((MOP+eps)*((UB(j)-LB(j))*Mu+LB(j)));
                    end
                else
                    r3=rand();
                    if r3>0.5
                        Xnew(i,j)=Best_PP(1,j)-MOP*((UB(j)-LB(j))*Mu+LB(j));
                    else
                        Xnew(i,j)=Best_PP(1,j)+MOP*((UB(j)-LB(j))*Mu+LB(j));
                    end
                end               
            end
            
        end
     for j=1:size(X,2)   
        Flag_UB=Xnew(i,j)>UB'; % check if they exceed (up) the boundaries
        Flag_LB=Xnew(i,j)<LB'; % check if they exceed (down) the boundaries
        Xnew(i,j)=(Xnew(i,j).*(~(Flag_UB+Flag_LB)))+UB'.*Flag_UB+LB'.*Flag_LB;
     end
        Ffun_new(1,i)=fobj(Xnew(i,:));  % calculate Fitness function 
        if Ffun_new(1,i)<Ffun(1,i)
            X(i,:)=Xnew(i,:);
            Ffun(1,i)=Ffun_new(1,i);
        end
        if Ffun(1,i)<Best_FF
        Best_FF=Ffun(1,i);
        Best_PP=X(i,:);
        end
       
    end
    

    %Update the convergence curve
    Conv_curve(C_Iter)=Best_FF;
    
    %Print the best solution details after every 50 iterations
    if mod(C_Iter,100)==0
        display(['At iteration ', num2str(C_Iter), ' the best solution fitness is ', num2str(Best_FF)]);
    end
     
    C_Iter=C_Iter+1;  % incremental iteration
   
end



