
clc
clear 
close all
format long

Sca_no=30;       % Number of search agents
sca_no=30;
%Function_name=ll;      % Function ID
Max_iteration=1000;       % Maximum number of iterations
N = Sca_no;      % Number of Searcher Agents "
nPop=N;
Solution_no=N;            %Number of search solutions

M_Iter=Max_iteration;    %Maximum number of iterations
MaxIt=M_Iter;
Max_Iteration  = Max_iteration;                % Maximu
Q=1;            % ACO Parameter
tau0=10;        % Initial Phromone             (ACO)
alpha=0.3;      % Phromone Exponential Weight  (ACO)
rho=0.1;        % Evaporation Rate             (ACO)
beta_min=0.2;   % Lower Bound of Scaling Factor (DE)
beta_max=0.8;   % Upper Bound of Scaling Factor (DE)
pCR=0.2;        % Crossover Probability         (DE)
 ElitistCheck=1; % GSA Parameter
 Rpower=1;       % GSA Parameter
 min_flag=1; % 1: minimization, 0: maximization (GSA)
 chValueInitial=20; % CGSA
% n = [30,30,30,30,2,2,2,4,10,30,30,30, 2,2,2,2,5,10,30, 2,2,30,2,2,2,2,2,30,30,30]; % dimensions for classical functions
 RunNo  = 30; % Run 30 times
func_name='F34';
[lb,ub,dim,fobj]=G_F_d(func_name);

for k = [ 1 : 1 : RunNo ]
    
% % %   
%[lb,ub,dim,fobj]=G_F_d(func_name);
[Top_gazelle_fit_DE,Top_gazelle_pos_DE,Convergence_curve_DE]=HGOADE(N,M_Iter,func_name);
if abs(Top_gazelle_fit_DE) < 1e-8
         Top_gazelle_fit_DE = 0;
end

BestSolutions1(k)=Top_gazelle_fit_DE;

[F_best,Lbest,BestChart]=GSA(func_name,N,Max_Iteration,ElitistCheck,min_flag,Rpower)
BestSolutions2(k)=F_best;

[Top_gazelle_fit,Top_gazelle_pos,Convergence_curve1]=GOA2(N,M_Iter,func_name);
BestSolutions3(k)=Top_gazelle_fit;

[Best_FF,Best_PP,Conv_curve]=AOAn(Solution_no,M_Iter,func_name); % Call the AOA 
BestSolutions4(k) = Best_FF;



[gBestScore,gBest,GlobalBestCost]= CPSOGSA(func_name, N, Max_Iteration);
BestSolutions5(k) = gBestScore;

[Best_scoreSCA,Best_poss,SCA_cg_curve]=SCA(func_name, N, Max_Iteration);
BestSolutions6(k) = Best_scoreSCA ;


[PcgCurve,GBEST]=pso(func_name,N,Max_Iteration);
BestSolutions7(k) = GBEST.O;

[BestCost,BestSol] = bbo( func_name, N, Max_Iteration);
BestSolutions8(k) = BestSol.Cost;

[BestSolDE,DBestSol,BestCostDE] = DE(func_name, N, Max_Iteration,beta_min,beta_max,pCR);
BestSolutions9(k) = BestSolDE.Cost ;

[Food_Fitness,Food_Position,Convergence_curve]=SSA(func_name, N, Max_Iteration);
BestSolutions10(k)=Food_Fitness;


[Best_scoreGWO,Best_posss,GWO_cg_curve]=GWO(func_name, N, Max_Iteration);
BestSolutions11(k) = Best_scoreGWO;




     disp(['Run # ' , num2str(k), ' HGOADE Running :  ' , num2str( Top_gazelle_fit_DE )]);
     disp(['Run # ',num2str(k), ' GSA :' ,num2str(F_best)]);
     disp(['Run # ',num2str(k), ' GOA Solutions :' ,num2str(Top_gazelle_fit)]);
     disp(['Run # ' , num2str(k), ' Best_FFnew:  ' , num2str( Best_FF)]);
     disp(['Run # ' , num2str(k), ' gBestScore:  ' , num2str( gBestScore)]);
     disp(['Run # ' , num2str(k), ' Best_scoreSCA :  ' , num2str( Best_scoreSCA)]);
     disp(['Run # ' , num2str(k), ' GBEST.O: ' , num2str( GBEST.O)]);
     disp(['Run # ' , num2str(k), ' BestSol.Cost:  ' , num2str( BestSol.Cost)]);
     disp(['Run # ' , num2str(k), ' BestSolDE.Cost :  ' , num2str( BestSolDE.Cost)]);
     disp(['Run # ' , num2str(k), ' Food_Fitness by SSA:  ' , num2str( Food_Fitness )]);
     disp(['Run # ' , num2str(k), ' Best_scoreGWO :  ' , num2str( Best_scoreGWO)]);
    


format long
filename='SimulationEng.txt';
    Average1= mean(BestSolutions1);
    StandDP1=std(BestSolutions1);
    Med1 = median(BestSolutions1); 
    BestValueP1 = min(BestSolutions1);
    WorstValueP1 =max(BestSolutions1);
     dlmwrite(filename,BestValueP1,'-append');
     dlmwrite(filename,WorstValueP1,'-append');
     dlmwrite(filename,Average1,'-append');
     dlmwrite(filename,StandDP1,'-append');
     dlmwrite(filename,Med1,'-append');
     
     Average2= mean(BestSolutions2);
    StandDP2=std(BestSolutions2);
    Med2 = median(BestSolutions2); 
    BestValueP2 = min(BestSolutions2);
    WorstValueP2 =max(BestSolutions2);
     dlmwrite(filename,BestValueP2,'-append');
     dlmwrite(filename,WorstValueP2,'-append');
     dlmwrite(filename,Average2,'-append');
     dlmwrite(filename,StandDP2,'-append');
     dlmwrite(filename,Med2,'-append');
     
     Average3= mean(BestSolutions3);
    StandDP3=std(BestSolutions3);
    Med3 = median(BestSolutions3); 
    BestValueP3 = min(BestSolutions3);
    WorstValueP3 =max(BestSolutions3);
     dlmwrite(filename,BestValueP3,'-append');
     dlmwrite(filename,WorstValueP3,'-append');
     dlmwrite(filename,Average3,'-append');
     dlmwrite(filename,StandDP3,'-append');
     dlmwrite(filename,Med3,'-append');

   
     Average4= mean(BestSolutions4);
    StandDP4=std(BestSolutions4);
    Med4 = median(BestSolutions4); 
    BestValueP4 = min(BestSolutions4);
    WorstValueP4 =max(BestSolutions4);
     dlmwrite(filename,BestValueP4,'-append');
     dlmwrite(filename,WorstValueP4,'-append');
     dlmwrite(filename,Average4,'-append');
     dlmwrite(filename,StandDP4,'-append');
     dlmwrite(filename,Med4,'-append');
    
     Average5= mean(BestSolutions5);
    StandDP5=std(BestSolutions5);
    Med5 = median(BestSolutions5); 
    BestValueP5 = min(BestSolutions5);
    WorstValueP5 =max(BestSolutions5);
     dlmwrite(filename,BestValueP5,'-append');
     dlmwrite(filename,WorstValueP5,'-append');
     dlmwrite(filename,Average5,'-append');
     dlmwrite(filename,StandDP5,'-append');
     dlmwrite(filename,Med5,'-append');

    Average6= mean(BestSolutions6);
    StandDP6=std(BestSolutions6);
    Med6 = median(BestSolutions6); 
    BestValueP6 = min(BestSolutions6);
    WorstValueP6 =max(BestSolutions6);
     dlmwrite(filename,BestValueP6,'-append');
     dlmwrite(filename,WorstValueP6,'-append');
     dlmwrite(filename,Average6,'-append');
     dlmwrite(filename,StandDP6,'-append');
     dlmwrite(filename,Med6,'-append');
     
     
    Average7= mean(BestSolutions7);
    StandDP7=std(BestSolutions7);
    Med7 = median(BestSolutions7); 
    BestValueP7 = min(BestSolutions7);
    WorstValueP7 =max(BestSolutions7);
     dlmwrite(filename,BestValueP7,'-append');
     dlmwrite(filename,WorstValueP7,'-append');
     dlmwrite(filename,Average7,'-append');
     dlmwrite(filename,StandDP7,'-append');
     dlmwrite(filename,Med7,'-append');


    Average8= mean(BestSolutions8);
    StandDP8=std(BestSolutions8);
    Med8 = median(BestSolutions8); 
    BestValueP8 = min(BestSolutions8);
    WorstValueP8 =max(BestSolutions8);
     dlmwrite(filename,BestValueP8,'-append');
     dlmwrite(filename,WorstValueP8,'-append');
     dlmwrite(filename,Average8,'-append');
     dlmwrite(filename,StandDP8,'-append');
     dlmwrite(filename,Med8,'-append');
     
     Average9= mean(BestSolutions9);
    StandDP9=std(BestSolutions9);
    Med9 = median(BestSolutions9); 
    BestValueP9 = min(BestSolutions9);
    WorstValueP9 =max(BestSolutions9);
     dlmwrite(filename,BestValueP9,'-append');
     dlmwrite(filename,WorstValueP9,'-append');
     dlmwrite(filename,Average9,'-append');
     dlmwrite(filename,StandDP9,'-append');
     dlmwrite(filename,Med9,'-append');
     
     Average10= mean(BestSolutions10);
    StandDP10=std(BestSolutions10);
    Med10 = median(BestSolutions10); 
    BestValueP10 = min(BestSolutions10);
    WorstValueP10 =max(BestSolutions10);
     dlmwrite(filename,BestValueP10,'-append');
     dlmwrite(filename,WorstValueP10,'-append');
     dlmwrite(filename,Average10,'-append');
     dlmwrite(filename,StandDP10,'-append');
     dlmwrite(filename,Med10,'-append');
     
     
    
     Average11= mean(BestSolutions11);
    StandDP11=std(BestSolutions11);
    Med11 = median(BestSolutions11); 
    BestValueP11= min(BestSolutions11);
    WorstValueP11 =max(BestSolutions11);
     dlmwrite(filename,BestValueP11,'-append');
     dlmwrite(filename,WorstValueP11,'-append');
     dlmwrite(filename,Average11,'-append');
     dlmwrite(filename,StandDP11,'-append');
     dlmwrite(filename,Med11,'-append');
     
    % Average12= mean(BestSolutions12);
    % StandDP12=std(BestSolutions12);
    % Med12 = median(BestSolutions12); 
    % BestValueP12 = min(BestSolutions12);
    % WorstValueP12 =max(BestSolutions12);
    %  dlmwrite(filename,BestValueP12,'-append');
    %  dlmwrite(filename,WorstValueP12,'-append');
    %  dlmwrite(filename,Average12,'-append');
    %  dlmwrite(filename,StandDP12,'-append');
    %  dlmwrite(filename,Med12,'-append');
     
    %  Average13= mean(BestSolutions13);
    % StandDP13=std(BestSolutions13);
    % Med13 = median(BestSolutions13); 
    % BestValueP13 = min(BestSolutions13);
    % WorstValueP13 =max(BestSolutions13);
    %  dlmwrite(filename,BestValueP13,'-append');
    %  dlmwrite(filename,WorstValueP13,'-append');
    %  dlmwrite(filename,Average13,'-append');
    %  dlmwrite(filename,StandDP13,'-append');
    %  dlmwrite(filename,Med13,'-append');
    % 
    % 
    %  Average14= mean(BestSolutions14);
    % StandDP14=std(BestSolutions14);
    % Med14 = median(BestSolutions14); 
    % BestValueP14 = min(BestSolutions14);
    % WorstValueP14 =max(BestSolutions14);
    %  dlmwrite(filename,BestValueP14,'-append');
    %  dlmwrite(filename,WorstValueP14,'-append');
    %  dlmwrite(filename,Average14,'-append');
    %  dlmwrite(filename,StandDP14,'-append');
    %  dlmwrite(filename,Med14,'-append');
    % 


 %     figure
    figure('Position',[500 500 700 297])
%figure('Position',[284   214   660   290])
%Draw search space
subplot(1,2,1);
semilogy(1:Max_Iteration,Convergence_curve_DE,'Color',"#FF0000",'LineStyle','--','LineWidth',3);
     hold on
     semilogy(1:Max_Iteration,BestChart,'Color',"#00FF00",'LineStyle','--','LineWidth',1);
     semilogy(1:Max_Iteration,Convergence_curve1,'Color',"#000000",'LineStyle','--','LineWidth',1);
     semilogy(1:Max_Iteration,Conv_curve,'Color',"#00FFFF",'LineStyle','--','LineWidth',1);
     semilogy(1:Max_Iteration,GlobalBestCost,'Color',"#FF00FF",'LineStyle','--','LineWidth',1);
     semilogy(1:Max_Iteration,SCA_cg_curve,'Color',"#77AC30",'LineStyle','--','LineWidth',1);
     semilogy(1:Max_Iteration,PcgCurve,'Color',"#FFFF00",'LineStyle','--','LineWidth',1);
     semilogy(1:Max_Iteration,BestCost,'Color',"#D95319",'LineStyle','--','LineWidth',1);  
     semilogy(1:Max_Iteration,BestCostDE,'Color',"#EDB120",'LineStyle','--','LineWidth',1);
     semilogy(1:Max_Iteration,Convergence_curve,'Color',"#7E2F8E",'LineStyle','--','LineWidth',1);
     semilogy(1:Max_Iteration,GWO_cg_curve,'Color',"#0000FF",'LineStyle','--','LineWidth',1);
     % semilogy(1:Max_Iteration,PDConv1,'Color',"#A2142F",'LineStyle','--','LineWidth',1);


   
%    semilogy(1:Max_Iteration,BestCostACO,'DisplayName','ACO','Color','g','Marker','d','LineStyle','-','LineWidth',1,'MarkerSize',2);
%    semilogy(1:Max_Iteration,SSA_cg_curve,'DisplayName','SSA','Color','c','Marker','x','LineStyle','--','LineWidth',1,'MarkerSize',2);
%    semilogy(1:Max_Iteration,SCA_cg_curve,'DisplayName','SCA','Color','b','Marker','*','LineStyle','--','LineWidth',1,'MarkerSize',2);
%    semilogy(1:Max_Iteration,GWO_cg_curve,'DisplayName','GWO','Color','k','Marker','o','LineStyle','--','LineWidth',1,'MarkerSize',2);
% %    semilogy(1:Max_Iteration,CBestChart,'DisplayName','CGSA','Color','g','LineStyle',':','LineWidth',2);
% % %     
title ('\fontsize{15}\bf Convergence Curve (F34)')
% % title ('\fontsize{15}\bf CEC2020 Function');
% % title ('\fontsize{15}\bf Welded Beam Design');
% % title ('\fontsize{15}\bf Compression Spring Design');
% % title ('\fontsize{15}\bf Pressure Vessel Design');
% % title ('\fontsize{15}\bf Speed Reducer Design');
% % title ('\fontsize{15}\bf Gear Train Design');
% % title ('\fontsize{15}\bf Multiple Disk clutch Brake Design');
% % title ('\fontsize{15}\bf Three-bar truss design problem');
% % title ('\fontsize{15}\bf Cantilever beam');
% % title ('\fontsize{15}\bf Tubular column design');
% % title ('\fontsize{15}\bf Piston lever');
% % title ('\fontsize{15}\bf Corrugated bulkhead design');
% % title ('\fontsize{15}\bf Car side impact design');
% % title ('\fontsize{15}\bf Reinforced concrete beam design');
 xlabel('\fontsize{15}\bf Iteration');
 ylabel('\fontsize{15}\bf Fitness(Best-so-far)');
 
 axis tight
 grid on
 box on
% %  legend('\fontsize{12}\bf GOA','\fontsize{12}\bf nAOA','\fontsize{12}\bf AOA','\fontsize{12}\bf CPSOGSA','\fontsize{12}\bf GSA','\fontsize{12}\bf PSO','\fontsize{12}\bf BBO','\fontsize{12}\bf DE','\fontsize{12}\bf ACO','\fontsize{12}\bf SSA','\fontsize{12}\bf SCA','\fontsize{12}\bf GWO');
% %  legend('\fontsize{12}\bf GOA','\fontsize{12}\bf nAOA','\fontsize{12}\bf AOA','\fontsize{12}\bf CPSOGSA','\fontsize{12}\bf PSO','\fontsize{12}\bf BBO','\fontsize{12}\bf DE','\fontsize{12}\bf ACO','\fontsize{12}\bf SSA','\fontsize{12}\bf SCA','\fontsize{12}\bf GWO');
 legend('\fontsize{12}\bf HGOADE','\fontsize{12}\bf GSA','\fontsize{12}\bf GOA','\fontsize{12}\bf AOA','\fontsize{12}\bf CPSOGSA','\fontsize{12}\bf SCA','\fontsize{12}\bf PSO','\fontsize{12}\bf BBO','\fontsize{12}\bf DE','\fontsize{12}\bf SSA','\fontsize{12}\bf GWO');
%  
% %  legend('\fontsize{12}\bf CPSOGSA','\fontsize{12}\bf GSA','\fontsize{12}\bf PSO','\fontsize{12}\bf BBO',...
%     '\fontsize{12}\bf DE','\fontsize{12}\bf ACO','\fontsize{12}\bf GWO','\fontsize{12}\bf SCA','\fontsize{12}\bf SSA','\fontsize{12}\bf CGSA',1);

end