
function   fitness=evaluateF(X,F_obj)

[dim,N]=size(X);
for i=1:N 
    L=X(:,i)';
    %calculation of objective function
    fitness(i)=F_obj(L);
end