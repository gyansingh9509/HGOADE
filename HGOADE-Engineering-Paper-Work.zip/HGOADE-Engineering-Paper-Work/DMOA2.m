%
% Dwarf Mongoose Optimization Algorithm source code 
%
%  
% paper:
% Jeffrey O. Agushaka and Absalom E. Ezugwu
% Dwarf Mongoose Optimization Algorithm: A Nature-inspired Metaheuristic
%  
%  
% E-mails: 218088307@stu.ukzn.ac.za            Jeffrey O. Agushaka 
%           ezugwuA@ukzn.ac.za                 Absalom E. Ezugwu
%
%

% clc;
% clear;
% close all;
function [Best_Sol,Best_Cost]=DMOA2(nPop,MaxIt,Function_name)% call DMOA 
%% Problem Definition
[down,up,dim]=benchmark_functions_details(Function_name);
% CostFunction=@(x) Sphere(x);        % Cost Function

nVar=dim;             % Number of Decision Variables

VarSize=[1 nVar];   % Decision Variables Matrix Size

VarMin=down';         % Decision Variables Lower Bound
VarMax=up';         % Decision Variables Upper Bound

%% DMOA Settings

% MaxIt=200;              % Maximum Number of Iterations
% 
% nPop=100;               % Population Size (Family Size)

nBabysitter= 3;         % Number of babysitters

nAlphaGroup=nPop-nBabysitter;         % Number of Alpha group

nScout=nAlphaGroup;         % Number of Scouts

L=round(0.6*nVar*nBabysitter); % Babysitter Exchange Parameter 

peep=1;             % Alpha female�s vocalization 
%% Initialization

% Empty Mongoose Structure
empty_mongoose.Position=[];
empty_mongoose.Cost=[];

% Initialize Population Array
pop=repmat(empty_mongoose,nAlphaGroup,1);

% Initialize Best Solution Ever Found
Best_Sol.Cost=inf;
tau=inf;
Iter=1;
sm=inf(nAlphaGroup,1);

% Create Initial Population
for i=1:nAlphaGroup
    pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
    pop(i).Cost=benchmark_functions(pop(i).Position,Function_name,dim);
    if pop(i).Cost<Best_Sol.Cost
        Best_Sol=pop(i);
    end
end

% Abandonment Counter
C=zeros(nAlphaGroup,1);
CF=(1-Iter/MaxIt)^(2*Iter/MaxIt);

% Array to Hold Best Cost Values
Best_Cost=zeros(MaxIt,1);

%% DMOA Main Loop

for it=1:MaxIt
    
    % Alpha group
     F=zeros(nAlphaGroup,1);
     MeanCost = mean([pop.Cost]);
    for i=1:nAlphaGroup
        
        % Calculate Fitness Values and Selection of Alpha
        F(i) = exp(-pop(i).Cost/MeanCost); % Convert Cost to Fitness
    end
        P=F/sum(F);
      % Foraging led by Alpha female
    for m=1:nAlphaGroup
        
        % Select Alpha female
        i=RouletteWheelSelection(P);
        
        % Choose k randomly, not equal to Alpha
        K=[1:i-1 i+1:nAlphaGroup];
        k=K(randi([1 numel(K)]));
        
        % Define Vocalization Coeff.
        phi=(peep/2)*unifrnd(-1,+1,VarSize);
        
        % New Mongoose Position
        newpop.Position=pop(i).Position+phi.*(pop(i).Position-pop(k).Position);
        % Check boundary VarMin,VarMax
%         for j=1:size(X,2)   
        Flag_UB=newpop.Position>VarMax; % check if they exceed (up) the boundaries
        Flag_LB=newpop.Position<VarMin; % check if they exceed (down) the boundaries
        newpop.Position=(newpop.Position.*(~(Flag_UB+Flag_LB)))+VarMax.*Flag_UB+VarMin.*Flag_LB;
%        end
        % Evaluation
        newpop.Cost=benchmark_functions(newpop.Position,Function_name,dim);
        
        % Comparision
        if newpop.Cost<=pop(i).Cost
            pop(i)=newpop;
        else
            C(i)=C(i)+1;
        end
        
    end   
    
    % Scout group
    for i=1:nScout
        
        % Choose k randomly, not equal to i
        K=[1:i-1 i+1:nAlphaGroup];
        k=K(randi([1 numel(K)]));
        
        % Define Vocalization Coeff.
        phi=(peep/2)*unifrnd(-1,+1,VarSize);
        
        % New Mongoose Position
        newpop.Position=pop(i).Position+phi.*(pop(i).Position-pop(k).Position);
        % Check boundary
        Flag_UB=newpop.Position>VarMax; % check if they exceed (up) the boundaries
        Flag_LB=newpop.Position<VarMin; % check if they exceed (down) the boundaries
        newpop.Position=(newpop.Position.*(~(Flag_UB+Flag_LB)))+VarMax.*Flag_UB+VarMin.*Flag_LB;
        % Evaluation
        newpop.Cost=benchmark_functions(newpop.Position,Function_name,dim);
        
        % Sleeping mould
        sm(i)=(newpop.Cost-pop(i).Cost)/max(newpop.Cost,pop(i).Cost);
        
        % Comparision
        if newpop.Cost<=pop(i).Cost
            pop(i)=newpop;
        else
            C(i)=C(i)+1;
        end
        
    end    
    % Babysitters
    for i=1:nBabysitter
         newtau=mean(sm);
        if C(i)>=L
%             pop(i).Position=unifrnd(VarMin,VarMax,VarSize);
%             pop(i).Cost=benchmark_functions(pop(i).Position,Function_name,dim);
              M=(pop(i).Position.*sm)/pop(i).Position;
                if newtau<tau
                   newpop.Position=pop(i).Position-CF*phi*rand.*(pop(i).Position-M);
                else
                   newpop.Position=pop(i).Position+CF*phi*rand.*(pop(i).Position-M);
                end
                tau=newtau;
                Flag_UB=newpop.Position>VarMax; % check if they exceed (up) the boundaries
                Flag_LB=newpop.Position<VarMin; % check if they exceed (down) the boundaries
                newpop.Position=(newpop.Position.*(~(Flag_UB+Flag_LB)))+VarMax.*Flag_UB+VarMin.*Flag_LB;
            C(i)=0;
        end
    end    
     % Update Best Solution Ever Found
    for i=1:nAlphaGroup
        if pop(i).Cost<=Best_Sol.Cost
            Best_Sol=pop(i);
        end
    end    
        
   % Next Mongoose Position
%    newtau=mean(sm);
%    for i=1:nScout
%         M=(pop(i).Position.*sm)/pop(i).Position;
%         if newtau>tau
%            newpop.Position=pop(i).Position-CF*phi*rand.*(pop(i).Position-M);
%         else
%            newpop.Position=pop(i).Position+CF*phi*rand.*(pop(i).Position-M);
%         end
%         tau=newtau;
%    end
       
%    % Update Best Solution Ever Found
%     for i=1:nAlphaGroup
%         if pop(i).Cost<=BestSol.Cost
%             BestSol=pop(i);
%         end
%     end
    
    % Store Best Cost Ever Found
    Best_Cost(it)=Best_Sol.Cost;
    
    % Display Iteration Information
    if mod(it,100)==0
    disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(Best_Cost(it))]);
    end
    
    it=it+1;
end
    
%% Results

% figure;
% %plot(BestCost,'LineWidth',2);
% semilogy(BestCost,'LineWidth',2);
% xlabel('Iteration');
% ylabel('Best Cost');
% grid on;
