
% This is a hybridised algorithm of Gazelle Optimization Algorithm with
% Differential Evaluation
function [Top_gazelle_fit_DE,Top_gazelle_pos_DE,Convergence_curve_DE]=Hybrid_GOA_DE(SearchAgents_no,M_Iter,Function_name)
    % Define the boundary and dimension of the benchmark function
    [low, up, dim] = benchmark_functions_details(Function_name);
    lb = low';
    ub = up';

    % Initialize the positions and fitness
    Top_gazelle_pos_DE = zeros(dim,1);
    Top_gazelle_fit_DE = inf; 
    Convergence_curve_DE = zeros(1,M_Iter);
    stepsize = zeros(dim, SearchAgents_no);
    fitness = inf(1, SearchAgents_no);

    % Initialization of gazelle positions
    gazelle = initializationGOA(dim, SearchAgents_no, ub, lb);
    Xmin = repmat(ones(1, dim) .* lb, SearchAgents_no, 1);
    Xmax = repmat(ones(1, dim) .* ub, SearchAgents_no, 1);

    Iter = 2;
    PSRs = 0.34;
    S = 0.88;
    s = rand();
    beta_min = 0.2; 
    beta_max = 0.8;
    pCR = 0.2;

    while Iter <= M_Iter
        % Detecting top predator
        for i = 1:size(gazelle, 1)
            Flag4ub = gazelle(i,:) > ub;
            Flag4lb = gazelle(i,:) < lb;    
            gazelle(i,:) = (gazelle(i,:) .* (~(Flag4ub + Flag4lb))) + ub .* Flag4ub + lb .* Flag4lb;                    

            fitness(i,1) = benchmark_functions(gazelle(i,:), Function_name, dim);

            if fitness(i,1) < Top_gazelle_fit_DE 
                Top_gazelle_fit_DE = fitness(i,1); 
                Top_gazelle_pos_DE = gazelle(i,:);
            end          
        end

        % Marine Memory saving
        if Iter == 0
            fit_old = fitness;    
            Prey_old = gazelle;
        

        Inx = (fit_old < fitness);
        Indx = repmat(Inx, 1, dim);
        gazelle = Indx .* Prey_old + ~Indx .* gazelle;
        fitness = Inx .* fit_old + ~Inx .* fitness;

        fit_old = fitness;    
        Prey_old = gazelle;
        end
        Elite = repmat(Top_gazelle_pos_DE, SearchAgents_no, 1);  % Elite gazelle
        CF = (1 - Iter/M_Iter)^(2*Iter/M_Iter);
        RL = 0.05 * levy(SearchAgents_no, dim, 1.5);   % Levy random number vector
        RB = randn(SearchAgents_no, dim);              % Brownian random number vector
        
%         % Apply DE mutation and crossover
%         for i = 1:SearchAgents_no
%             A = randperm(SearchAgents_no);
%             A(A == i) = [];
%             a = A(1); b = A(2); c = A(3);
%             
%             beta = rand(1, dim) .* (beta_max - beta_min) + beta_min;
%             y = gazelle(a,:) + beta .* (gazelle(b,:) - gazelle(c,:));
%             y = max(y, lb');
%             y = min(y, ub');
% 
%             z = zeros(size(gazelle(i,:)));
%             j0 = randi([1 dim]);
%             for j = 1:dim
%                 if j == j0 || rand <= pCR
%                     z(j) = y(j);
%                 else
%                     z(j) = gazelle(i,j);
%                 end
%             end
% 
%             
% %             NewSol(i).Cost = benchmark_functions(NewSol.Position, Function_name, dim);
% 
% %             if NewSol(i).Cost < fitness(i)
% %                 gazelle(i,:) = NewSol.Position;
% %                 fitness(i) = NewSol(i).Cost;
% % 
% %                 if fitness(i) < Top_gazelle_fit
% %                     Top_gazelle_fit = fitness(i);
% %                     Top_gazelle_pos = gazelle(i,:);
% %                 end
% %             end
% Newgazelle(i,:) = z;
%         end

        % Exploitation and Exploration
        for i = 1:SearchAgents_no
            A = randperm(SearchAgents_no);
            A(A == i) = [];
            a = A(1); b = A(2); c = A(3);
            
            beta = rand(1, dim) .* (beta_max - beta_min) + beta_min;
            y = gazelle(a,:) + beta .* (gazelle(b,:) - gazelle(c,:));
            y = max(y, lb');
            y = min(y, ub');

            z = zeros(size(gazelle(i,:)));
            j0 = randi([1 dim]);
            for j = 1:dim
                if j == j0 || rand <= pCR
                    z(j) = y(j);
                else
                    z(j) = gazelle(i,j);
                end
            end

            
%             NewSol(i).Cost = benchmark_functions(NewSol.Position, Function_name, dim);

%             if NewSol(i).Cost < fitness(i)
%                 gazelle(i,:) = NewSol.Position;
%                 fitness(i) = NewSol(i).Cost;
% 
%                 if fitness(i) < Top_gazelle_fit
%                     Top_gazelle_fit = fitness(i);
%                     Top_gazelle_pos = gazelle(i,:);
%                 end
%             end
Newgazelle(i,:) = z;
            for j = 1:dim
                R = rand();
                r = rand();
                if mod(Iter, 2) == 0
                    mu = -1;
                else
                    mu = 1;
                end

                if r > 0.5 
                    stepsize(i,j) = RB(i,j) * (Elite(i,j) - RB(i,j) * Newgazelle(i,j));                    
                    gazelle(i,j) = Newgazelle(i,j) + s * R * stepsize(i,j);
                else 
                    if i > size(gazelle, 1)/2
                        stepsize(i,j) = RB(i,j) * (RL(i,j) * Elite(i,j) - Newgazelle(i,j));
                        gazelle(i,j) = Elite(i,j) + S * mu * CF * stepsize(i,j); 
                    else
                        stepsize(i,j) = RL(i,j) * (Elite(i,j) - RL(i,j) * Newgazelle(i,j));                     
                        gazelle(i,j) = Newgazelle(i,j) + S * mu * R * stepsize(i,j);  
                    end  
                end
            end
        end

        % Detecting top predator
        for i = 1:size(gazelle, 1)
            Flag4ub = gazelle(i,:) > ub;
            Flag4lb = gazelle(i,:) < lb;    
            gazelle(i,:) = (gazelle(i,:) .* (~(Flag4ub + Flag4lb))) + ub .* Flag4ub + lb .* Flag4lb;                    

            fitness(i,1) = benchmark_functions(gazelle(i,:), Function_name, dim);

            if fitness(i,1) < Top_gazelle_fit_DE 
                Top_gazelle_fit_DE = fitness(i,1); 
                Top_gazelle_pos_DE = gazelle(i,:);
            end          
        end

        % Marine Memory saving
        if Iter == 0
            fit_old = fitness;    
            Prey_old = gazelle;
       

        Inx = (fit_old < fitness);
        Indx = repmat(Inx, 1, dim);
        gazelle = Indx .* Prey_old + ~Indx .* gazelle;
        fitness = Inx .* fit_old + ~Inx .* fitness;

        fit_old = fitness;    
        Prey_old = gazelle;
        end
        % Eddy formation and FADs’ effect
        if rand() < PSRs
            U = rand(SearchAgents_no, dim) < PSRs;                                                                                              
            gazelle = gazelle + CF * ((Xmin + rand(SearchAgents_no, dim) .* (Xmax - Xmin)) .* U);
        else
            r = rand();  
            Rs = size(gazelle, 1);
            stepsize = (PSRs * (1 - r) + r) * (gazelle(randperm(Rs), :) - gazelle(randperm(Rs), :));
            gazelle = gazelle + stepsize;
        end
        
        
        Convergence_curve_DE(Iter)=Top_gazelle_fit_DE;
        if mod(Iter,100)==0
            disp(['Iteration ' num2str(Iter) ': HGAODE Running = ' num2str(Top_gazelle_fit_DE)]);
        end
        
        
        Iter = Iter + 1;  
%        Convergence_curve_DE(Iter) = Top_gazelle_fit_DE;
         
    end
end
